# 3.1 (5 points)

Fill in the rest of the table below:

|      | they | can | can | fish | END |
|------|------|-----|-----|------|-----|
| Start|  n/a | n/a | n/a | n/a  | n/a |
| Noun | -2   |     |     |      | n/a |
| Verb | -13  |     |     |      | n/a |
| End  | n/a  | n/a | n/a | n/a  | -17 |


# 4.3 (5 points)

Do you think the predicted tags "PRON AUX AUX NOUN PUNCT" for the sentence "They can can fish ." are correct? Use your understanding of parts-of-speech from the notes.










